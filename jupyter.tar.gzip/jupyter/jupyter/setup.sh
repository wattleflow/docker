#/bin/bash

rm -rf /var/lib/apt/lists

apt -y update && apt -y upgrade

apt install -y git python3 python3-pip ca-certificates

#apt install -y netcat nmap netcat iproute2 libffi-dev

tee /etc/pip.conf <<EOF
[global]
proxy="http://localhost:3128"
EOF

python3 -m pip install --no-cache-dir --upgrade pip

[[ -d /workspace/requirements.txt ]] && python3 -m pip install --no-cache-dir -r /workspace/requirements.txt

cd /workspace/transformer

python3 -m spacy download en_core_web_sm

# RUN python3 -m pip install --no-cache-dir --upgrade pip
# RUN python3 -m pip install --no-cache-dir -r /workspace/requirements.txt
# RUN pip install --proxy $PROXY -r /workspace/requirements.txt
# RUN python3 -m spacy download en_core_web_sm